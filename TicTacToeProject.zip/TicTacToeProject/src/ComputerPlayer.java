import javafx.scene.control.Button;

public class ComputerPlayer {

	
	public void computerMove(Board board, Button[][] cell)//this method does not work, I'm not exactly sure why
	{
		//computer moves to wherever there's an available space
		//if there's an available space and it's the computer's turn, then it should click a button
		
		 // What spaces are available -Shree
		
		String available_spaces = "";
		 
		 for(int i = 0; i < 3; i ++) {
			 for(int j = 0; j <3; j ++) {
				 if(cell[i][j].getText().equals("")) {
					 available_spaces += i +" "+j+","; 
				 }
			 }
		 }
		 
		 String [] spaces = available_spaces.split(",");
		 
		 int random_index = (int)(Math.random()*(spaces.length-1));
		 
		 String [] chosen = spaces[random_index].split(" "); 
		
		 int x = Integer.parseInt(chosen[0]); 
		 int y = Integer.parseInt(chosen[1]); 
		 
		 cell[x][y].setText("O"); 
		 cell[x][y].setDisable(true);
		 
				 
		 
		 
		
	}

}
