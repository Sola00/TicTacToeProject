import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.GridPane;

public class Board {
	//private Button[][] cell = new Button[3][3];
	private ComputerPlayer c = new ComputerPlayer();
	private String playerTurn = "X";
	boolean computerTurn = false;
	private int humanCount = 0;
	private int computerCount = 0;


	public Board()
	{	
	}
	
	public boolean availableSpace(Button[][] b)
	{
		for(int i=0; i<3; i++)
		{
			for(int j=0; j<3; j++)
			{
				//if it's an empty space, return true
				if(b[i][j].getText().equals("")) {
					return true;
				}
			}
		}
		return false;
	}
	
	
	public boolean isComputerTurn() {
		return computerTurn;
	}

	public void setComputerTurn(boolean computerTurn) {
		this.computerTurn = computerTurn;
	}

	public String decideTurn()
	{
			if(this.playerTurn == "X") 
			{
				this.playerTurn = "O";
			}
			else 
			{
				this.playerTurn = "X";
			}
			return this.playerTurn;
			 
	}
	
//	public void decideWhoWin(Button[][] b)
//	{
//		//make a 3x3 string to store button text
//		String Cell2[][] = new String[3][3];
//		//initialize button text to its position
//		Cell2[0][0]= b[0][0].getText();
//		Cell2[0][1] = b[0][1].getText();
//		Cell2[0][2] = b[0][2].getText();
//		Cell2[1][0] = b[1][0].getText();
//		Cell2[1][1] = b[1][1].getText();
//		Cell2[1][2] = b[1][2].getText();
//		Cell2[2][0] = b[2][0].getText();
//		Cell2[2][1] = b[2][1].getText();
//		Cell2[2][2] = b[2][2].getText();
//		
//		int count1 = 0; 
//		int count2 = 0;
//		int count3 = 0;
//		int count4 = 0;
//		
//		boolean win = false;
//		
//			 for(int i=0;i<3;i++)
//		        {
//		          for(int j=0;j<3;j++)
//		          {
//		        	  //checking right diagonal
//		        	  if(i==j && Cell2[i][j].equalsIgnoreCase(playerTurn))              
//			                count1++;
//			          //checking left diagonal     
//			          if(j==2-i && Cell2[i][j].equalsIgnoreCase(playerTurn))             
//			                count2++;
//			          //checking rows
//			          if(Cell2[i][j].equalsIgnoreCase(playerTurn))                 
//			                count3++;
//			          //checking columns
//			          if(Cell2[j][i].equalsIgnoreCase(playerTurn))                  
//			                count4++;      
//		            }
//	            
//	            if(count3==3 || count4==3)                                                          
//	            win=true;
//	                    
//	            count3=0;
//	            count4=0; 
//	              
//	        }
//	        //check win for diagonals
//	        if(count1==3 || count2==3)         
//	        win=true;
//	        
//
//	        //check if human or computer wins
//	        if(win==true)                
//	        {
//	            if(playerTurn=="X") {
//	            	humanCount++;
//		            winnerAlert(b);
//	            }
//	            else 
//	            {
//	            	computerCount++;
//		            winnerAlert(b);
//	            }
//	        }
//	       
//	       }//end method
	
	
	public void winnerAlert(String letter)
	{
		Alert alert = new Alert(AlertType.INFORMATION);
		alert.setTitle("Tic Tac Toe");
		alert.setHeaderText(null);
		alert.setContentText(letter + " wins!");
		alert.showAndWait();
		
	}
	public void tieAlert()
	{
		Alert alert = new Alert(AlertType.INFORMATION);
		alert.setTitle("Tic Tac Toe");
		alert.setHeaderText(null);
		alert.setContentText("It's a tie");
		alert.showAndWait();
		
	}
	public boolean tie(Button[][] cell) {
		for(int i=0; i<3; i++) {
			for(int j=0; j<3; j++) {
				if(cell[i][j].getText().equals("")) {
					return false;
				}
			}
		}
		return true;
	}
	public boolean hasWon(String letter, Button[][] b)
	{
		for(int i=0; i<3; i++)
		{
			//checking rows
				if(b[i][0].getText().equals(letter) && b[i][1].getText().equals(letter) && b[i][2].getText().equals(letter))
				{
					return true;
				}
		}
		for(int j=0; j<3; j++)
		{
			//checking columns
				if(b[0][j].getText().equals(letter) && b[1][j].getText().equals(letter) && b[2][j].getText().equals(letter))
				{
					return true;
				}
		}
		//checking diagonal from left
		if(b[0][0].getText().equals(letter) && b[1][1].getText().equals(letter) && b[2][2].getText().equals(letter)) 
		{
			return true;
		}
		//checking diagonal form right
		if(b[0][2].getText().equals(letter) && b[1][1].getText().equals(letter) && b[2][0].getText().equals(letter)) 
		{
			return true;
		}
		return false;
	}
}
