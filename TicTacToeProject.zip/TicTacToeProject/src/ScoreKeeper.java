import javafx.scene.control.Label;

public class ScoreKeeper {
	//static 
	public int xPlayerWins;
	public int oPlayerWins;
	public int numOfTies;
	private int humanCount = 0;
	private int computerCount = 0;
	private Label humanLbl = new Label("Human: ");
	private Label compLbl = new Label("Computer: ");

	public ScoreKeeper()
	{
		xPlayerWins = 0;
		oPlayerWins = 0;
		numOfTies = 0;
	}
	public void getScores() {
		humanLbl.setText(String.valueOf(humanCount));
		compLbl.setText(String.valueOf(computerCount));
	}
	public void getScore(Board board)
	{
		xPlayerWins = 0;
		oPlayerWins = 0;
		numOfTies = 0;
		for(int i=0; i<3; i++)
		{
			for(int j=0; j< 3;j++)
			{
				if(board.hasWon("X", null) == true)
				{
					xPlayerWins++;
				}
				else if(board.hasWon("O", null)== true)
				{
					oPlayerWins++;
				}
				else 
				{
					numOfTies++;
				}
			}
		}
		
	}
	
}
