import java.awt.Font;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
//This version does play with the computer
//It does not keep score. I started a method to do so, but was not able to implement it into the GUI
//I could not figure out how to get it to recognize a tie/draw, so if there is one, there is no alert
//I did my best with what I knew and could research
public class TicTacToeGui extends Application {
	Button reset = new Button("Play Again?");
	private Button[][] cell = new Button[3][3];
	private Label humanLbl = new Label("Human: ");
	private Label compLbl = new Label("Computer: ");

	public static void main(String[] args) {
 
		Application.launch(args);
	}

	@Override
	public void start(Stage primaryStage) throws Exception {
		GridPane gp = new GridPane();

		Board board = new Board();
		ComputerPlayer cp = new ComputerPlayer();
		ScoreKeeper sk = new ScoreKeeper();

		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 3; j++) {
				cell[i][j] = new Button();
				gp.add(cell[i][j], j, i);
				cell[i][j].setPrefSize(70, 70);
				cell[i][j].setTextFill(Color.DARKGREEN);
				cell[i][j].setStyle("-fx-font-size:20");
			}
		}
		
		BorderPane bp = new BorderPane();
		bp.setCenter(gp);
		bp.setBottom(reset);

		Scene scene = new Scene(bp, 300, 300);
		primaryStage.setTitle("TicTacToe");
		primaryStage.setScene(scene);
		primaryStage.show();

		cell[0][0].setOnAction(e -> {
			cell[0][0].setText("X");
			board.setComputerTurn(true);
			if(board.hasWon("X", cell)) {
				//sk.xplayerwins++;
				board.winnerAlert("X");
				cell[0][0].setDisable(false);
				reset(primaryStage);
			}
			//board.decideWhoWin(cell);
			
			else if (board.availableSpace(cell)) {
				cp.computerMove(board, cell);
				board.setComputerTurn(false);
				if(board.hasWon("O", cell)) {
					board.winnerAlert("O");
					cell[0][0].setDisable(false);
					reset(primaryStage);
				}

			}
			//board.decideWhoWin(cell);
			else if (board.tie(cell)) {
				board.tieAlert();
				cell[0][0].setDisable(false);
				reset(primaryStage);	  }  
	        
			cell[0][0].setDisable(true);
		});
		

		cell[0][1].setOnAction(e -> {
			cell[0][1].setText("X");
			board.setComputerTurn(true);
			if(board.hasWon("X", cell)) {
				board.winnerAlert("X");
				cell[0][1].setDisable(false);
				reset(primaryStage);
			}
			//board.decideWhoWin(cell);
			
			else if (board.availableSpace(cell)) {
				cp.computerMove(board, cell);
				board.setComputerTurn(false);
				if(board.hasWon("O", cell)) {
					board.winnerAlert("O");
					cell[0][1].setDisable(false);
					reset(primaryStage);
				}
				

			}
			//board.decideWhoWin(cell);
			else if (board.tie(cell)) {
				board.tieAlert();
				cell[0][1].setDisable(false);
				reset(primaryStage);	  }  
	        
			cell[0][1].setDisable(true);
		});
		
		

		cell[0][2].setOnAction(e -> {
			cell[0][2].setText("X");
			board.setComputerTurn(true);
			if(board.hasWon("X", cell)) {
				board.winnerAlert("X");
				cell[0][2].setDisable(false);
				reset(primaryStage);
			}
			//board.decideWhoWin(cell);
			
			else if (board.availableSpace(cell)) {
				cp.computerMove(board, cell);
				board.setComputerTurn(false);
				if(board.hasWon("O", cell)) {
					board.winnerAlert("O");
					cell[0][2].setDisable(false);
					reset(primaryStage);
				}

			}
			//board.decideWhoWin(cell);
			else if (board.tie(cell)) {
				board.tieAlert();
				cell[0][2].setDisable(false);
				reset(primaryStage);	  }  
	        

			cell[0][2].setDisable(true);
		});

		
		cell[1][0].setOnAction(e -> {
			cell[1][0].setText("X");
			board.setComputerTurn(true);
			if(board.hasWon("X", cell)) {
				board.winnerAlert("X");
				cell[1][0].setDisable(false);
				reset(primaryStage);
			}
			//board.decideWhoWin(cell);
			
			else if (board.availableSpace(cell)) {
				cp.computerMove(board, cell);
				board.setComputerTurn(false);
				if(board.hasWon("O", cell)) {
					board.winnerAlert("O");
					cell[1][0].setDisable(false);
					reset(primaryStage);
				}

			}
			//board.decideWhoWin(cell);
			else if (board.tie(cell)) {
				board.tieAlert();
				 cell[1][0].setDisable(false);
				reset(primaryStage);	  }  
	       
			cell[1][0].setDisable(true);
		});
		 

		cell[1][1].setOnAction(e -> {
			cell[1][1].setText("X");
			board.setComputerTurn(true);
			if(board.hasWon("X", cell)) {
				board.winnerAlert("X");
				cell[1][1].setDisable(false);
				reset(primaryStage);
			}
			//board.decideWhoWin(cell);
			
			else if (board.availableSpace(cell)) {
				cp.computerMove(board, cell);
				board.setComputerTurn(false);
				if(board.hasWon("O", cell)) {
					board.winnerAlert("O");
					cell[1][1].setDisable(false);
					reset(primaryStage);
				}

			}
			//board.decideWhoWin(cell);
			else if (board.tie(cell)) {
				board.tieAlert();
				cell[1][1].setDisable(false);
				reset(primaryStage);	   
	        
			}
			cell[1][1].setDisable(true);

		});
		

		cell[1][2].setOnAction(e -> {
			cell[1][2].setText("X");
			board.setComputerTurn(true);
			if(board.hasWon("X", cell)) {
				board.winnerAlert("X");
				cell[1][2].setDisable(false);
				reset(primaryStage);
			}
			//board.decideWhoWin(cell);
			
			else if (board.availableSpace(cell)) {
				cp.computerMove(board, cell);
				board.setComputerTurn(false);
				if(board.hasWon("O", cell)) {
					board.winnerAlert("O");
					cell[1][2].setDisable(false);
					reset(primaryStage);
				}

			}
			//board.decideWhoWin(cell);
			else if (board.tie(cell)) {
				board.tieAlert();
				cell[1][2].setDisable(false);
				reset(primaryStage);	   
	        }
			cell[1][2].setDisable(true);

		});
		

		cell[2][0].setOnAction(e -> {
			cell[2][0].setText("X");
			board.setComputerTurn(true);
			if(board.hasWon("X", cell)) {
				board.winnerAlert("X");
				cell[2][0].setDisable(false);
				reset(primaryStage);
			}
			
			//board.decideWhoWin(cell);
			
			else if (board.availableSpace(cell)) {
				cp.computerMove(board, cell);
				board.setComputerTurn(false);
				if(board.hasWon("O", cell)) {
					board.winnerAlert("O");
					cell[2][0].setDisable(false);
					reset(primaryStage);
				}
//				else if (board.tie(cell)) {
//					board.tieAlert();
//					reset(primaryStage);
//				}

			}
			
			else if (board.tie(cell))
			{
				board.tieAlert();
				cell[2][0].setDisable(false);
				reset(primaryStage);
			
	        
			} cell[2][0].setDisable(true);

		});
		
		
		cell[2][1].setOnAction(e -> {
			cell[2][1].setText("X");
			board.setComputerTurn(true);
			if(board.hasWon("", cell)) {
				board.winnerAlert("X");
				cell[2][1].setDisable(false);
				reset(primaryStage);
			}
			//board.decideWhoWin(cell);
			
			else if (board.availableSpace(cell)) {
				cp.computerMove(board, cell);
				board.setComputerTurn(false);
				if(board.hasWon("O", cell)) {
					board.winnerAlert("O");
					cell[2][1].setDisable(false);
					reset(primaryStage);
				}

			}
			//board.decideWhoWin(cell);

			else if (board.tie(cell)) {
				board.tieAlert();
				cell[2][1].setDisable(false);
				reset(primaryStage);}
			
			cell[2][1].setDisable(true);

		});
		

		cell[2][2].setOnAction(e -> {
			cell[2][2].setText("X");
			board.setComputerTurn(true);
			if(board.hasWon("X", cell)) {
				board.winnerAlert("X");
				cell[2][2].setDisable(false);
				reset(primaryStage);
				
			}
			//board.decideWhoWin(cell);
			
			else if (board.availableSpace(cell)) {
				cp.computerMove(board, cell);
				board.setComputerTurn(false);
				if(board.hasWon("O", cell)) {
					board.winnerAlert("O");
					cell[2][2].setDisable(false);
					reset(primaryStage);
					
				}

			}
			//board.decideWhoWin(cell);

			else if (board.tie(cell)) {
				board.tieAlert();
				cell[2][2].setDisable(false);
				reset(primaryStage);	      
				
			}
			cell[2][2].setDisable(true);
		});
//		


		reset.setOnAction(e -> {
//			for (int i = 0; i < 3; i++) {
//				for (int j = 0; j < 3; j++) {
//					cell[i][j].setText("");
//				}
//			}
			reset(primaryStage);
		});
	}
	
	public void reset(Stage primaryStage) {
		try {
			start(primaryStage);
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}

}
